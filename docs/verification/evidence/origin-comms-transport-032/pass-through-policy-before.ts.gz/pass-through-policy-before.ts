export function fixtureFetch(url: string, init?: RequestInit): Promise<Response> {
  return fetch(url, init);
}
